import dgram from "dgram";

export const socket = dgram.createSocket("udp4");